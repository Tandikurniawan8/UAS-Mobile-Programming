import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'package:myapp/form-pendaftaran/device-device-frame.dart';
// import 'package:myapp/form-pendaftaran/top-a-regular-a-flat.dart';
// import 'package:myapp/form-pendaftaran/rectangle-1.dart';
// import 'package:myapp/form-pendaftaran/amik-1.dart';
// import 'package:myapp/form-pendaftaran/penerimaan-mahasiswa-baru.dart';
// import 'package:myapp/form-pendaftaran/rectangle-2.dart';
// import 'package:myapp/form-pendaftaran/rectangle-12.dart';
// import 'package:myapp/form-pendaftaran/rectangle-18.dart';
// import 'package:myapp/form-pendaftaran/rectangle-21.dart';
// import 'package:myapp/form-pendaftaran/data-diri.dart';
// import 'package:myapp/form-pendaftaran/data-alamat-asli.dart';
// import 'package:myapp/form-pendaftaran/data-pendidikan.dart';
// import 'package:myapp/form-pendaftaran/pilihan-program-studi.dart';
// import 'package:myapp/form-pendaftaran/rectangle-3.dart';
// import 'package:myapp/form-pendaftaran/rectangle-9.dart';
// import 'package:myapp/form-pendaftaran/rectangle-11.dart';
// import 'package:myapp/form-pendaftaran/rectangle-17.dart';
// import 'package:myapp/form-pendaftaran/rectangle-8.dart';
// import 'package:myapp/form-pendaftaran/rectangle-7.dart';
// import 'package:myapp/form-pendaftaran/rectangle-20.dart';
// import 'package:myapp/form-pendaftaran/rectangle-19.dart';
// import 'package:myapp/form-pendaftaran/rectangle-23.dart';
// import 'package:myapp/form-pendaftaran/rectangle-16.dart';
// import 'package:myapp/form-pendaftaran/rectangle-15.dart';
// import 'package:myapp/form-pendaftaran/rectangle-14.dart';
// import 'package:myapp/form-pendaftaran/rectangle-13.dart';
// import 'package:myapp/form-pendaftaran/rectangle-10.dart';
// import 'package:myapp/form-pendaftaran/rectangle-6.dart';
// import 'package:myapp/form-pendaftaran/rectangle-5.dart';
// import 'package:myapp/form-pendaftaran/rectangle-4.dart';
// import 'package:myapp/form-pendaftaran/nama-lengkap-.dart';
// import 'package:myapp/form-pendaftaran/kecamatan-.dart';
// import 'package:myapp/form-pendaftaran/kode-pos-.dart';
// import 'package:myapp/form-pendaftaran/kabupaten-.dart';
// import 'package:myapp/form-pendaftaran/provinsi-.dart';
// import 'package:myapp/form-pendaftaran/program-studi-.dart';
// import 'package:myapp/form-pendaftaran/asal-sekolah-.dart';
// import 'package:myapp/form-pendaftaran/pendidikan-terkahir-.dart';
// import 'package:myapp/form-pendaftaran/alamat-lengkap-.dart';
// import 'package:myapp/form-pendaftaran/nomor-telephone-.dart';
// import 'package:myapp/form-pendaftaran/nama-ibu-kandung-.dart';
// import 'package:myapp/form-pendaftaran/jenis-kelamin-.dart';
// import 'package:myapp/form-pendaftaran/nomor-identitas-nik-.dart';
// import 'package:myapp/form-pendaftaran/agama-.dart';
// import 'package:myapp/form-pendaftaran/email-.dart';
// import 'package:myapp/form-pendaftaran/kewarganegaraan-.dart';
// import 'package:myapp/form-pendaftaran/tempattanggal-lahir-.dart';
// import 'package:myapp/form-pendaftaran/navigation-expandmore24px.dart';
// import 'package:myapp/form-pendaftaran/navigation-expandmore24px-WcR.dart';
// import 'package:myapp/form-pendaftaran/navigation-expandmore24px-uwP.dart';
// import 'package:myapp/form-pendaftaran/navigation-expandmore24px-wQD.dart';
// import 'package:myapp/form-pendaftaran/rectangle-24.dart';
// import 'package:myapp/form-pendaftaran/rectangle-25.dart';
// import 'package:myapp/form-pendaftaran/submit.dart';
// import 'package:myapp/form-pendaftaran/delete.dart';
// import 'package:myapp/form-pendaftaran/iphone-14-pro-max-1.dart';
// import 'package:myapp/form-pendaftaran/iphone-14-pro-max-2.dart';
// import 'package:myapp/form-pendaftaran/iphone-14-pro-max-3.dart';
// import 'package:myapp/form-pendaftaran/iphone-14-pro-max-4.dart';
// import 'package:myapp/form-pendaftaran/iphone-14-pro-max-5.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
	@override
	Widget build(BuildContext context) {
	return MaterialApp(
		title: 'Flutter',
		debugShowCheckedModeBanner: false,
		scrollBehavior: MyCustomScrollBehavior(),
		theme: ThemeData(
		primarySwatch: Colors.blue,
		),
		home: Scaffold(
		body: SingleChildScrollView(
			child: Scene(),
		),
		),
	);
	}
}
