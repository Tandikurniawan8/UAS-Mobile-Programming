import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone14promax2xZ7 (23:333)
        padding: EdgeInsets.fromLTRB(9*fem, 20*fem, 9*fem, 20*fem),
        width: double.infinity,
        height: 932*fem,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Container(
          // devicedeviceframe3Kf (206:519)
          padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
          width: double.infinity,
          height: double.infinity,
          decoration: BoxDecoration (
            border: Border.all(color: Color(0x7f8e918f)),
            color: Color(0xff1d1b20),
            borderRadius: BorderRadius.circular(18*fem),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                // autogroupaozh8M7 (JbNi3BUQz8Q9Nv7oSBAozh)
                padding: EdgeInsets.fromLTRB(1*fem, 18*fem, 0*fem, 0*fem),
                width: double.infinity,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // statusbarFgd (I206:519;50785:11431)
                      margin: EdgeInsets.fromLTRB(23*fem, 0*fem, 24*fem, 18*fem),
                      width: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Container(
                            // timenRf (I206:519;50785:11431;50758:11370)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 141*fem, 0*fem),
                            child: Text(
                              '9:30',
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.4285714286*ffem/fem,
                                letterSpacing: 0.14*fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                          Container(
                            // cameracutoutfVT (I206:519;50785:11431;50758:11371)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 124*fem, 0*fem),
                            width: 24*fem,
                            height: 24*fem,
                            child: Image.asset(
                              'assets/form-pendaftaran/images/camera-cutout-wv1.png',
                              width: 24*fem,
                              height: 24*fem,
                            ),
                          ),
                          Container(
                            // righticonsnKB (I206:519;50785:11431;50758:11372)
                            width: 46*fem,
                            height: 17*fem,
                            child: Image.asset(
                              'assets/form-pendaftaran/images/right-icons-6Em.png',
                              width: 46*fem,
                              height: 17*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // quilted6qf (24:875)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2*fem),
                      width: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // row1quiltedpmf (24:877)
                            padding: EdgeInsets.fromLTRB(0*fem, 95*fem, 0*fem, 0*fem),
                            width: double.infinity,
                            height: 191*fem,
                            decoration: BoxDecoration (
                              image: DecorationImage (
                                fit: BoxFit.cover,
                                image: AssetImage (
                                  'assets/form-pendaftaran/images/row-1-quilted-bg.png',
                                ),
                              ),
                            ),
                            child: Container(
                              // overlayw5b (24:878)
                              padding: EdgeInsets.fromLTRB(46.5*fem, 10*fem, 46.5*fem, 14*fem),
                              width: double.infinity,
                              height: double.infinity,
                              decoration: BoxDecoration (
                                color: Color(0x60000000),
                              ),
                              child: Center(
                                // labelfXP (24:879)
                                child: SizedBox(
                                  child: Container(
                                    constraints: BoxConstraints (
                                      maxWidth: 318*fem,
                                    ),
                                    child: Text(
                                      'HI,USERR\nSELAMAT DATANG ANDA SEDANG BERADA DIHALAMAN UTAMA',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 16*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.5*ffem/fem,
                                        letterSpacing: 0.150000006*fem,
                                        color: Color(0xdd000000),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 4*fem,
                          ),
                          Container(
                            // row2uRj (24:881)
                            width: double.infinity,
                            height: 112*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // row2quiltedeeD (24:882)
                                  padding: EdgeInsets.fromLTRB(0*fem, 64*fem, 0*fem, 0*fem),
                                  width: 133.5*fem,
                                  height: double.infinity,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/form-pendaftaran/images/row-2-quilted-bg-TJH.png',
                                      ),
                                    ),
                                  ),
                                  child: Container(
                                    // overlayMYd (24:883)
                                    padding: EdgeInsets.fromLTRB(12*fem, 12*fem, 12*fem, 12*fem),
                                    width: double.infinity,
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0x60000000),
                                    ),
                                    child: Text(
                                      'PROFILE',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 16*ffem,
                                        fontWeight: FontWeight.w700,
                                        height: 1.5*ffem/fem,
                                        letterSpacing: 0.150000006*fem,
                                        color: Color(0xdd000000),
                                      ),
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  width: 4*fem,
                                ),
                                Container(
                                  // row2quiltedpx1 (24:886)
                                  padding: EdgeInsets.fromLTRB(0*fem, 64*fem, 0*fem, 0*fem),
                                  width: 133.5*fem,
                                  height: double.infinity,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/form-pendaftaran/images/row-2-quilted-bg-y4m.png',
                                      ),
                                    ),
                                  ),
                                  child: Container(
                                    // overlayx2d (24:887)
                                    padding: EdgeInsets.fromLTRB(12*fem, 12*fem, 12*fem, 12*fem),
                                    width: double.infinity,
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0x60000000),
                                    ),
                                    child: Text(
                                      'AKADEMIK',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 16*ffem,
                                        fontWeight: FontWeight.w700,
                                        height: 1.5*ffem/fem,
                                        letterSpacing: 0.150000006*fem,
                                        color: Color(0xdd000000),
                                      ),
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  width: 4*fem,
                                ),
                                Container(
                                  // row2quiltedEkq (24:890)
                                  padding: EdgeInsets.fromLTRB(0*fem, 64*fem, 0*fem, 0*fem),
                                  width: 136*fem,
                                  height: double.infinity,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/form-pendaftaran/images/row-2-quilted-bg.png',
                                      ),
                                    ),
                                  ),
                                  child: Container(
                                    // overlayAPb (24:891)
                                    padding: EdgeInsets.fromLTRB(12*fem, 12*fem, 12*fem, 12*fem),
                                    width: double.infinity,
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0x60000000),
                                    ),
                                    child: Text(
                                      'KEGIATAN',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 16*ffem,
                                        fontWeight: FontWeight.w700,
                                        height: 1.5*ffem/fem,
                                        letterSpacing: 0.150000006*fem,
                                        color: Color(0xdd000000),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 4*fem,
                          ),
                          Container(
                            // row3EPT (24:894)
                            width: double.infinity,
                            height: 191*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // row3quiltednA5 (24:895)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 0*fem),
                                  padding: EdgeInsets.fromLTRB(0*fem, 143*fem, 0*fem, 0*fem),
                                  width: 203.5*fem,
                                  height: double.infinity,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/form-pendaftaran/images/row-3-quilted-bg.png',
                                      ),
                                    ),
                                  ),
                                  child: Container(
                                    // overlayUob (24:896)
                                    padding: EdgeInsets.fromLTRB(12*fem, 12*fem, 12*fem, 12*fem),
                                    width: double.infinity,
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0x60000000),
                                    ),
                                    child: Text(
                                      'KEMAHASISWAAN',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 16*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.5*ffem/fem,
                                        letterSpacing: 0.150000006*fem,
                                        color: Color(0xdd000000),
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  // row3quiltednpH (24:899)
                                  padding: EdgeInsets.fromLTRB(0*fem, 143*fem, 0*fem, 0*fem),
                                  width: 203.5*fem,
                                  height: double.infinity,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/form-pendaftaran/images/row-3-quilted-bg-cQ9.png',
                                      ),
                                    ),
                                  ),
                                  child: Container(
                                    // overlayKJR (24:900)
                                    padding: EdgeInsets.fromLTRB(12*fem, 12*fem, 12*fem, 12*fem),
                                    width: double.infinity,
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0x60000000),
                                    ),
                                    child: Text(
                                      'PMB',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 16*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.5*ffem/fem,
                                        letterSpacing: 0.150000006*fem,
                                        color: Color(0xdd000000),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // amik1pFB (24:911)
                      width: 411*fem,
                      height: 227*fem,
                      child: Image.asset(
                        'assets/form-pendaftaran/images/amik-1-EGh.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                // toparegularaflatx6V (24:853)
                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 35*fem),
                padding: EdgeInsets.fromLTRB(19*fem, 16*fem, 19.4*fem, 16*fem),
                width: double.infinity,
                height: 56*fem,
                decoration: BoxDecoration (
                  color: Color(0xff0e5faa),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // leadingiconlusehighemphasis2s3 (I24:853;242:7083)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 36*fem, 0*fem),
                      width: 18*fem,
                      height: 12*fem,
                      child: Image.asset(
                        'assets/form-pendaftaran/images/leading-icon-l-use-high-emphasis.png',
                        width: 18*fem,
                        height: 12*fem,
                      ),
                    ),
                    Container(
                      // pagetitlevhX (I24:853;242:7084)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 108.52*fem, 0*fem),
                      child: Text(
                        'Dashboard',
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 20*ffem,
                          fontWeight: FontWeight.w500,
                          height: 1.2*ffem/fem,
                          letterSpacing: 0.150000006*fem,
                          color: Color(0xffd9d9d9),
                        ),
                      ),
                    ),
                    Container(
                      // trailingiconsDgd (I24:853;242:7085)
                      margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 0*fem, 2*fem),
                      height: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // trailingicon1jus (I24:853;242:7086)
                            margin: EdgeInsets.fromLTRB(0*fem, 0.5*fem, 31.04*fem, 0*fem),
                            width: 16.08*fem,
                            height: 19.5*fem,
                            child: Image.asset(
                              'assets/form-pendaftaran/images/trailing-icon-1.png',
                              width: 16.08*fem,
                              height: 19.5*fem,
                            ),
                          ),
                          Container(
                            // trailingicon2TL5 (I24:853;242:7087)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 29.92*fem, 0.08*fem),
                            width: 18.09*fem,
                            height: 19.92*fem,
                            child: Image.asset(
                              'assets/form-pendaftaran/images/trailing-icon-2.png',
                              width: 18.09*fem,
                              height: 19.92*fem,
                            ),
                          ),
                          Container(
                            // trailingicon3Ztu (I24:853;242:7088)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.51*fem),
                            width: 16.94*fem,
                            height: 17.49*fem,
                            child: Image.asset(
                              'assets/form-pendaftaran/images/trailing-icon-3.png',
                              width: 16.94*fem,
                              height: 17.49*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                // hometRP (I206:519;50792:11371;50783:11414)
                margin: EdgeInsets.fromLTRB(170*fem, 0*fem, 170*fem, 0*fem),
                width: double.infinity,
                height: 2*fem,
                decoration: BoxDecoration (
                  borderRadius: BorderRadius.circular(8*fem),
                  color: Color(0xffffffff),
                ),
              ),
            ],
          ),
        ),
      ),
          );
  }
}