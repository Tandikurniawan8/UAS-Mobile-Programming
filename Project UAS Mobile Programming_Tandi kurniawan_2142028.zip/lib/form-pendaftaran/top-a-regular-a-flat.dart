import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 412;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // toparegularaflat3nH (20:110)
        padding: EdgeInsets.fromLTRB(19*fem, 16*fem, 19.4*fem, 16*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff0e5faa),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // leadingiconlusehighemphasisx8Z (I20:110;242:7083)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 36*fem, 0*fem),
              width: 18*fem,
              height: 12*fem,
              child: Image.asset(
                'assets/form-pendaftaran/images/leading-icon-l-use-high-emphasis-Uau.png',
                width: 18*fem,
                height: 12*fem,
              ),
            ),
            Container(
              // pagetitleqTF (I20:110;242:7084)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 43.52*fem, 0*fem),
              child: Text(
                'Form Pendaftaran',
                style: SafeGoogleFont (
                  'Roboto',
                  fontSize: 20*ffem,
                  fontWeight: FontWeight.w500,
                  height: 1.2*ffem/fem,
                  letterSpacing: 0.150000006*fem,
                  color: Color(0xffd9d9d9),
                ),
              ),
            ),
            Container(
              // trailingiconsi1F (I20:110;242:7085)
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // trailingicon1TjX (I20:110;242:7086)
                    margin: EdgeInsets.fromLTRB(0*fem, 0.5*fem, 31.04*fem, 0*fem),
                    width: 16.08*fem,
                    height: 19.5*fem,
                    child: Image.asset(
                      'assets/form-pendaftaran/images/trailing-icon-1-8DX.png',
                      width: 16.08*fem,
                      height: 19.5*fem,
                    ),
                  ),
                  Container(
                    // trailingicon2NLh (I20:110;242:7087)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 29.92*fem, 0.08*fem),
                    width: 18.09*fem,
                    height: 19.92*fem,
                    child: Image.asset(
                      'assets/form-pendaftaran/images/trailing-icon-2-PEq.png',
                      width: 18.09*fem,
                      height: 19.92*fem,
                    ),
                  ),
                  Container(
                    // trailingicon3Ued (I20:110;242:7088)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.51*fem),
                    width: 16.94*fem,
                    height: 17.49*fem,
                    child: Image.asset(
                      'assets/form-pendaftaran/images/trailing-icon-3-KQd.png',
                      width: 16.94*fem,
                      height: 17.49*fem,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}