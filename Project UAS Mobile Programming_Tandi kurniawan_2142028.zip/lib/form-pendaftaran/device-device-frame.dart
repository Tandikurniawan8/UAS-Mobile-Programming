import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 412;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // devicedeviceframeC89 (16:34)
        padding: EdgeInsets.fromLTRB(24*fem, 18*fem, 24*fem, 8*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          border: Border.all(color: Color(0x7f8e918f)),
          color: Color(0xff1d1b20),
          borderRadius: BorderRadius.circular(18*fem),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // statusbarBPP (I16:34;50785:11431)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 840*fem),
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                    // time6FT (I16:34;50785:11431;50758:11370)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 141*fem, 0*fem),
                    child: Text(
                      '9:30',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.4285714286*ffem/fem,
                        letterSpacing: 0.14*fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                  Container(
                    // cameracutoutwms (I16:34;50785:11431;50758:11371)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 124*fem, 0*fem),
                    width: 24*fem,
                    height: 24*fem,
                    child: Image.asset(
                      'assets/form-pendaftaran/images/camera-cutout-Tz1.png',
                      width: 24*fem,
                      height: 24*fem,
                    ),
                  ),
                  Container(
                    // righticons3pu (I16:34;50785:11431;50758:11372)
                    width: 46*fem,
                    height: 17*fem,
                    child: Image.asset(
                      'assets/form-pendaftaran/images/right-icons-hQ5.png',
                      width: 46*fem,
                      height: 17*fem,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // homemF7 (I16:34;50792:11371;50783:11414)
              margin: EdgeInsets.fromLTRB(146*fem, 0*fem, 146*fem, 0*fem),
              width: double.infinity,
              height: 2*fem,
              decoration: BoxDecoration (
                borderRadius: BorderRadius.circular(8*fem),
                color: Color(0xffffffff),
              ),
            ),
          ],
        ),
      ),
          );
  }
}