import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone14promax4MDb (24:949)
        padding: EdgeInsets.fromLTRB(9*fem, 20*fem, 9*fem, 20*fem),
        width: double.infinity,
        height: 932*fem,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Container(
          // devicedeviceframefzy (24:950)
          padding: EdgeInsets.fromLTRB(0*fem, 18*fem, 0*fem, 8*fem),
          width: double.infinity,
          height: double.infinity,
          decoration: BoxDecoration (
            border: Border.all(color: Color(0x7f8e918f)),
            color: Color(0xff1d1b20),
            borderRadius: BorderRadius.circular(18*fem),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                // statusbarZqT (I24:950;50785:11431)
                margin: EdgeInsets.fromLTRB(24*fem, 0*fem, 24*fem, 10*fem),
                width: double.infinity,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Container(
                      // timegv5 (I24:950;50785:11431;50758:11370)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 141*fem, 0*fem),
                      child: Text(
                        '9:30',
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w500,
                          height: 1.4285714286*ffem/fem,
                          letterSpacing: 0.14*fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                    Container(
                      // cameracutoutbGM (I24:950;50785:11431;50758:11371)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 124*fem, 0*fem),
                      width: 24*fem,
                      height: 24*fem,
                      child: Image.asset(
                        'assets/form-pendaftaran/images/camera-cutout-g41.png',
                        width: 24*fem,
                        height: 24*fem,
                      ),
                    ),
                    Container(
                      // righticonsunq (I24:950;50785:11431;50758:11372)
                      width: 46*fem,
                      height: 17*fem,
                      child: Image.asset(
                        'assets/form-pendaftaran/images/right-icons-4RP.png',
                        width: 46*fem,
                        height: 17*fem,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                // groupaside3PF (24:1011)
                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 108*fem, 18*fem),
                padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 270*fem),
                width: 304*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x33000000),
                      offset: Offset(0*fem, 8*fem),
                      blurRadius: 5*fem,
                    ),
                    BoxShadow(
                      color: Color(0x1e000000),
                      offset: Offset(0*fem, 6*fem),
                      blurRadius: 15*fem,
                    ),
                    BoxShadow(
                      color: Color(0x23000000),
                      offset: Offset(0*fem, 16*fem),
                      blurRadius: 12*fem,
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // sysbarGWu (I24:1011;242:7817)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 40*fem),
                      width: double.infinity,
                      height: 24*fem,
                      decoration: BoxDecoration (
                        color: Color(0x60000000),
                      ),
                    ),
                    Container(
                      // accountswitcherQND (I24:1011;242:7818)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                      width: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // header94u (I24:1011;242:7818;242:7800)
                            margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 0*fem, 10*fem),
                            padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // autogroupplczfJ9 (JbNkkSHikVvyaNonPTpLcZ)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 30*fem),
                                  width: 42*fem,
                                  height: 40*fem,
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // imageo9T (I24:1011;242:7818;242:7801;242:8255)
                                        left: 0*fem,
                                        top: 0*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 40*fem,
                                            height: 40*fem,
                                            child: Image.asset(
                                              'assets/form-pendaftaran/images/image.png',
                                              width: 40*fem,
                                              height: 40*fem,
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // userimagesuserimagesi1X (24:1108)
                                        left: 2*fem,
                                        top: 0*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 40*fem,
                                            height: 40*fem,
                                            child: Image.asset(
                                              'assets/form-pendaftaran/images/user-images-user-images.png',
                                              width: 40*fem,
                                              height: 40*fem,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Text(
                                  // headline6zzd (I24:1011;242:7818;242:7803)
                                  'Hii,Userr',
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 20*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.2*ffem/fem,
                                    letterSpacing: 0.150000006*fem,
                                    color: Color(0xdd000000),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // divider7ZT (I24:1011;242:7818;242:7805;242:7473)
                            width: double.infinity,
                            height: 1*fem,
                            decoration: BoxDecoration (
                              color: Color(0x14212121),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // lineitemsGSM (I24:1011;242:7819)
                      width: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupqw6zRKF (JbNm5m4raxfMEA7UZhQw6Z)
                            padding: EdgeInsets.fromLTRB(18*fem, 0*fem, 18*fem, 12*fem),
                            width: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // lineitemZAZ (I24:1011;242:7820)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 130*fem, 24*fem),
                                  width: double.infinity,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // iconHsF (I24:1011;242:7821)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 34*fem, 1.68*fem),
                                        width: 20*fem,
                                        height: 16.82*fem,
                                        child: Image.asset(
                                          'assets/form-pendaftaran/images/icon-dJ1.png',
                                          width: 20*fem,
                                          height: 16.82*fem,
                                        ),
                                      ),
                                      Text(
                                        // labelc8q (I24:1011;242:7822)
                                        'DASHBOARD',
                                        style: SafeGoogleFont (
                                          'Roboto',
                                          fontSize: 14*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.7142857143*ffem/fem,
                                          letterSpacing: 0.1000000015*fem,
                                          color: Color(0x99000000),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // lineitemYHP (I24:1011;242:7823)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 158*fem, 0*fem),
                                  width: double.infinity,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // icongPb (I24:1011;242:7823;242:7762)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 34*fem, 1.68*fem),
                                        width: 20*fem,
                                        height: 16.82*fem,
                                        child: Image.asset(
                                          'assets/form-pendaftaran/images/icon-P3w.png',
                                          width: 20*fem,
                                          height: 16.82*fem,
                                        ),
                                      ),
                                      Text(
                                        // labelQKb (I24:1011;242:7823;242:7763)
                                        'PROFILE',
                                        style: SafeGoogleFont (
                                          'Roboto',
                                          fontSize: 14*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.7142857143*ffem/fem,
                                          letterSpacing: 0.1000000015*fem,
                                          color: Color(0x99000000),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // elements3lineitemcactiveYRo (I24:1011;242:7824)
                            padding: EdgeInsets.fromLTRB(18*fem, 12*fem, 161*fem, 12*fem),
                            width: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0x146200ee),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // icon49F (I24:1011;242:7824;242:7759)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 34*fem, 1.68*fem),
                                  width: 20*fem,
                                  height: 16.82*fem,
                                  child: Image.asset(
                                    'assets/form-pendaftaran/images/icon.png',
                                    width: 20*fem,
                                    height: 16.82*fem,
                                  ),
                                ),
                                Text(
                                  // labelMe9 (I24:1011;242:7824;242:7760)
                                  'AKADEMIK',
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.7142857143*ffem/fem,
                                    letterSpacing: 0.1000000015*fem,
                                    color: Color(0xff737171),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupj1mkgAd (JbNmHftgAady5CHdaWJ1MK)
                            padding: EdgeInsets.fromLTRB(18*fem, 12*fem, 18*fem, 24*fem),
                            width: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // lineitemQ6d (I24:1011;242:7825)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 147*fem, 0*fem),
                                  width: double.infinity,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // iconw6Z (I24:1011;242:7825;242:7762)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 34*fem, 1.68*fem),
                                        width: 20*fem,
                                        height: 16.82*fem,
                                        child: Image.asset(
                                          'assets/form-pendaftaran/images/icon-617.png',
                                          width: 20*fem,
                                          height: 16.82*fem,
                                        ),
                                      ),
                                      Text(
                                        // label4BB (I24:1011;242:7825;242:7763)
                                        'KEGIATAN',
                                        style: SafeGoogleFont (
                                          'Roboto',
                                          fontSize: 14*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.7142857143*ffem/fem,
                                          letterSpacing: 0.1000000015*fem,
                                          color: Color(0x99000000),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  height: 24*fem,
                                ),
                                Container(
                                  // lineitemPDT (I24:1011;242:7826)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 93*fem, 0*fem),
                                  width: double.infinity,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // iconKcu (I24:1011;242:7826;242:7762)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 34*fem, 1.68*fem),
                                        width: 20*fem,
                                        height: 16.82*fem,
                                        child: Image.asset(
                                          'assets/form-pendaftaran/images/icon-b7X.png',
                                          width: 20*fem,
                                          height: 16.82*fem,
                                        ),
                                      ),
                                      Text(
                                        // labelEzm (I24:1011;242:7826;242:7763)
                                        'KEMAHASISWAAN',
                                        style: SafeGoogleFont (
                                          'Roboto',
                                          fontSize: 14*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.7142857143*ffem/fem,
                                          letterSpacing: 0.1000000015*fem,
                                          color: Color(0x99000000),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  height: 24*fem,
                                ),
                                Container(
                                  // lineitemNLH (I24:1011;242:7827)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 36*fem, 0*fem),
                                  width: double.infinity,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // iconJUq (I24:1011;242:7827;242:7762)
                                        margin: EdgeInsets.fromLTRB(0*fem, 2.75*fem, 34*fem, 0*fem),
                                        width: 20*fem,
                                        height: 16.82*fem,
                                        child: Image.asset(
                                          'assets/form-pendaftaran/images/icon-EFs.png',
                                          width: 20*fem,
                                          height: 16.82*fem,
                                        ),
                                      ),
                                      Container(
                                        // label2Qq (I24:1011;242:7827;242:7763)
                                        constraints: BoxConstraints (
                                          maxWidth: 178*fem,
                                        ),
                                        child: Text(
                                          'PENERIMAAN MAHASISWA BARU (PMB)',
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 14*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1.7142857143*ffem/fem,
                                            letterSpacing: 0.1000000015*fem,
                                            color: Color(0x99000000),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  height: 24*fem,
                                ),
                                Container(
                                  // lineitemw21 (I24:1011;242:7830)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 159*fem, 0*fem),
                                  width: double.infinity,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogrouppzdffyb (JbNmeKxvYPDGDaiYXSpzDF)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 34*fem, 1.68*fem),
                                        width: 20*fem,
                                        height: 16.82*fem,
                                        child: Image.asset(
                                          'assets/form-pendaftaran/images/auto-group-pzdf.png',
                                          width: 20*fem,
                                          height: 16.82*fem,
                                        ),
                                      ),
                                      Text(
                                        // labelyjP (I24:1011;242:7830;242:7763)
                                        'LOGOUT',
                                        style: SafeGoogleFont (
                                          'Roboto',
                                          fontSize: 14*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.7142857143*ffem/fem,
                                          letterSpacing: 0.1000000015*fem,
                                          color: Color(0x99000000),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                // homehfP (I24:950;50792:11371;50783:11414)
                margin: EdgeInsets.fromLTRB(170*fem, 0*fem, 170*fem, 0*fem),
                width: double.infinity,
                height: 2*fem,
                decoration: BoxDecoration (
                  borderRadius: BorderRadius.circular(8*fem),
                  color: Color(0xffffffff),
                ),
              ),
            ],
          ),
        ),
      ),
          );
  }
}