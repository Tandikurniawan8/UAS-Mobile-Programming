import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone14promax3goj (24:912)
        padding: EdgeInsets.fromLTRB(9*fem, 0*fem, 9*fem, 0*fem),
        width: double.infinity,
        height: 932*fem,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Container(
          // devicedeviceframecSV (24:931)
          padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
          width: double.infinity,
          height: 892*fem,
          decoration: BoxDecoration (
            border: Border.all(color: Color(0x7f8e918f)),
            color: Color(0xff1d1b20),
            borderRadius: BorderRadius.circular(18*fem),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                // autogroup3izfiEd (JbNjp3ggSrCD8nYEZA3iZF)
                padding: EdgeInsets.fromLTRB(1*fem, 18*fem, 0*fem, 209*fem),
                width: double.infinity,
                height: 830*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      // statusbarECy (I24:931;50785:11431)
                      margin: EdgeInsets.fromLTRB(23*fem, 0*fem, 24*fem, 32*fem),
                      width: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Container(
                            // timekh7 (I24:931;50785:11431;50758:11370)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 141*fem, 0*fem),
                            child: Text(
                              '9:30',
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.4285714286*ffem/fem,
                                letterSpacing: 0.14*fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                          Container(
                            // cameracutoutrk9 (I24:931;50785:11431;50758:11371)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 124*fem, 0*fem),
                            width: 24*fem,
                            height: 24*fem,
                            child: Image.asset(
                              'assets/form-pendaftaran/images/camera-cutout-8sK.png',
                              width: 24*fem,
                              height: 24*fem,
                            ),
                          ),
                          Container(
                            // righticonsnNu (I24:931;50785:11431;50758:11372)
                            width: 46*fem,
                            height: 17*fem,
                            child: Image.asset(
                              'assets/form-pendaftaran/images/right-icons-v33.png',
                              width: 46*fem,
                              height: 17*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // amik1KNq (24:1132)
                      width: 411*fem,
                      height: 362*fem,
                      child: Image.asset(
                        'assets/form-pendaftaran/images/amik-1-4ZX.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                    Container(
                      // overlayevu (24:1133)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 48*fem),
                      padding: EdgeInsets.fromLTRB(24*fem, 10*fem, 24*fem, 11*fem),
                      width: double.infinity,
                      height: 117*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffd9d9d9),
                      ),
                      child: Center(
                        // labelmkd (24:1134)
                        child: SizedBox(
                          child: Container(
                            constraints: BoxConstraints (
                              maxWidth: 363*fem,
                            ),
                            child: Text(
                              'HI,USERR\nTERIMA KASIH BANYAK TELAH MENGISI FORM SEBLEMUNYA UNTUK INFORMASI SELANJUTNYA AKAN DI KIRIM MELALUI EMAIL ANDA.',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 16*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.5*ffem/fem,
                                letterSpacing: 0.150000006*fem,
                                color: Color(0xdd000000),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Container(
                      // autogrouphi1xT7f (JbNjBKEtJUtAUifrSChi1X)
                      margin: EdgeInsets.fromLTRB(32*fem, 0*fem, 274*fem, 0*fem),
                      width: double.infinity,
                      height: 20*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupwscrPGD (JbNjJ9Nqa7L98aBc8pWSCR)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 17*fem, 0*fem),
                            width: 44*fem,
                            height: double.infinity,
                            child: Stack(
                              children: [
                                Positioned(
                                  // rectangle24iJV (24:1162)
                                  left: 0*fem,
                                  top: 2*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 44*fem,
                                      height: 17*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff0e5faa),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // next1YV (24:1164)
                                  left: 11*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 21*fem,
                                      height: 20*fem,
                                      child: Text(
                                        'NEXT',
                                        style: SafeGoogleFont (
                                          'Roboto',
                                          fontSize: 8*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 2.5*ffem/fem,
                                          letterSpacing: 0.08*fem,
                                          color: Color(0xffd9d9d9),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupkbldWVF (JbNjN9GBC8rucPZGSwKbLD)
                            width: 44*fem,
                            height: double.infinity,
                            child: Stack(
                              children: [
                                Positioned(
                                  // rectangle25GDX (24:1167)
                                  left: 0*fem,
                                  top: 2*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 44*fem,
                                      height: 17*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xffbd0505),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // logoutnxZ (24:1168)
                                  left: 6*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 32*fem,
                                      height: 20*fem,
                                      child: Text(
                                        'LOGOUT',
                                        style: SafeGoogleFont (
                                          'Roboto',
                                          fontSize: 8*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 2.5*ffem/fem,
                                          letterSpacing: 0.08*fem,
                                          color: Color(0xffd9d9d9),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                // autogroupd6xs6TT (JbNjXDqP89vKHPbL5FD6Xs)
                width: double.infinity,
                height: 56*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // homeFLM (I24:931;50792:11371;50783:11414)
                      left: 170*fem,
                      top: 52*fem,
                      child: Align(
                        child: SizedBox(
                          width: 72*fem,
                          height: 2*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(8*fem),
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // toparegularaflatZ69 (24:1114)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(19*fem, 16*fem, 19.4*fem, 16*fem),
                        width: 412*fem,
                        height: 56*fem,
                        decoration: BoxDecoration (
                          color: Color(0xff0e5faa),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // leadingiconlusehighemphasiseNV (I24:1114;242:7083)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 36*fem, 0*fem),
                              width: 18*fem,
                              height: 12*fem,
                              child: Image.asset(
                                'assets/form-pendaftaran/images/leading-icon-l-use-high-emphasis-eBB.png',
                                width: 18*fem,
                                height: 12*fem,
                              ),
                            ),
                            Container(
                              // pagetitlex8H (I24:1114;242:7084)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 43.52*fem, 0*fem),
                              child: Text(
                                'Form Pendaftaran',
                                style: SafeGoogleFont (
                                  'Roboto',
                                  fontSize: 20*ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1.2*ffem/fem,
                                  letterSpacing: 0.150000006*fem,
                                  color: Color(0xffd9d9d9),
                                ),
                              ),
                            ),
                            Container(
                              // trailingiconsFt5 (I24:1114;242:7085)
                              margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 0*fem, 2*fem),
                              height: double.infinity,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // trailingicon1Nxh (I24:1114;242:7086)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0.5*fem, 31.04*fem, 0*fem),
                                    width: 16.08*fem,
                                    height: 19.5*fem,
                                    child: Image.asset(
                                      'assets/form-pendaftaran/images/trailing-icon-1-bah.png',
                                      width: 16.08*fem,
                                      height: 19.5*fem,
                                    ),
                                  ),
                                  Container(
                                    // trailingicon2VGd (I24:1114;242:7087)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 29.92*fem, 0.08*fem),
                                    width: 18.09*fem,
                                    height: 19.92*fem,
                                    child: Image.asset(
                                      'assets/form-pendaftaran/images/trailing-icon-2-gj3.png',
                                      width: 18.09*fem,
                                      height: 19.92*fem,
                                    ),
                                  ),
                                  Container(
                                    // trailingicon3Q8h (I24:1114;242:7088)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.51*fem),
                                    width: 16.94*fem,
                                    height: 17.49*fem,
                                    child: Image.asset(
                                      'assets/form-pendaftaran/images/trailing-icon-3-KkV.png',
                                      width: 16.94*fem,
                                      height: 17.49*fem,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
          );
  }
}