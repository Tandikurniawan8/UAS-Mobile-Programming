import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone14promax5GMf (206:518)
        padding: EdgeInsets.fromLTRB(0*fem, 20*fem, 0*fem, 20*fem),
        width: double.infinity,
        height: 932*fem,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Container(
          // devicedeviceframeNvV (23:334)
          width: 412*fem,
          height: double.infinity,
          decoration: BoxDecoration (
            border: Border.all(color: Color(0x7f8e918f)),
            color: Color(0xff1d1b20),
            borderRadius: BorderRadius.circular(18*fem),
          ),
          child: Stack(
            children: [
              Positioned(
                // statusbarggH (I23:334;50785:11431)
                left: 24*fem,
                top: 18*fem,
                child: Container(
                  width: 364*fem,
                  height: 24*fem,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Container(
                        // timeboF (I23:334;50785:11431;50758:11370)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 141*fem, 0*fem),
                        child: Text(
                          '9:30',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.4285714286*ffem/fem,
                            letterSpacing: 0.14*fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                      Container(
                        // cameracutoutVtd (I23:334;50785:11431;50758:11371)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 124*fem, 0*fem),
                        width: 24*fem,
                        height: 24*fem,
                        child: Image.asset(
                          'assets/form-pendaftaran/images/camera-cutout-Wjj.png',
                          width: 24*fem,
                          height: 24*fem,
                        ),
                      ),
                      Container(
                        // righticonscyF (I23:334;50785:11431;50758:11372)
                        width: 46*fem,
                        height: 17*fem,
                        child: Image.asset(
                          'assets/form-pendaftaran/images/right-icons-6ZF.png',
                          width: 46*fem,
                          height: 17*fem,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                // homek3s (I23:334;50792:11371;50783:11414)
                left: 170*fem,
                top: 882*fem,
                child: Align(
                  child: SizedBox(
                    width: 72*fem,
                    height: 2*fem,
                    child: Container(
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(8*fem),
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // rectangle273Ym (206:537)
                left: 125*fem,
                top: 216*fem,
                child: Align(
                  child: SizedBox(
                    width: 180*fem,
                    height: 18*fem,
                    child: Container(
                      decoration: BoxDecoration (
                        color: Color(0xffd9d9d9),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // rectangle26wu3 (206:538)
                left: 125*fem,
                top: 280*fem,
                child: Align(
                  child: SizedBox(
                    width: 180*fem,
                    height: 18*fem,
                    child: Container(
                      decoration: BoxDecoration (
                        color: Color(0xffd9d9d9),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // rectangle28U8H (208:541)
                left: 125*fem,
                top: 344*fem,
                child: Align(
                  child: SizedBox(
                    width: 180*fem,
                    height: 18*fem,
                    child: Container(
                      decoration: BoxDecoration (
                        color: Color(0xffd9d9d9),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // rectangle29Ca5 (208:542)
                left: 125*fem,
                top: 408*fem,
                child: Align(
                  child: SizedBox(
                    width: 180*fem,
                    height: 18*fem,
                    child: Container(
                      decoration: BoxDecoration (
                        color: Color(0xffd9d9d9),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // rectangle30X6Z (208:543)
                left: 125*fem,
                top: 472*fem,
                child: Align(
                  child: SizedBox(
                    width: 180*fem,
                    height: 18*fem,
                    child: Container(
                      decoration: BoxDecoration (
                        color: Color(0xffd9d9d9),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // signin3qb (208:540)
                left: 175*fem,
                top: 127.5*fem,
                child: Align(
                  child: SizedBox(
                    width: 87*fem,
                    height: 20*fem,
                    child: Text(
                      'SIGN IN',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 24*ffem,
                        fontWeight: FontWeight.w500,
                        height: 0.8333333333*ffem/fem,
                        letterSpacing: 0.24*fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // autogroupj6z79Nq (JbNnSUJhkc3SvJQHxtJ6Z7)
                left: 25*fem,
                top: 600*fem,
                child: Container(
                  width: 111*fem,
                  height: 20*fem,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        // autogroupa1vys3w (JbNnZy6DHuQtKTUf3ra1vy)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 23*fem, 0*fem),
                        width: 44*fem,
                        height: double.infinity,
                        child: Stack(
                          children: [
                            Positioned(
                              // rectangle26ayw (208:546)
                              left: 0*fem,
                              top: 1*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 44*fem,
                                  height: 17*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      color: Color(0xff0e5faa),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // submitJQ9 (208:549)
                              left: 7*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 30*fem,
                                  height: 20*fem,
                                  child: Text(
                                    'SUBMIT',
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 8*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 2.5*ffem/fem,
                                      letterSpacing: 0.08*fem,
                                      color: Color(0xffd9d9d9),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        // autogroupjzxvoLu (JbNneTxicgdkMkXGuEjZxV)
                        width: 44*fem,
                        height: double.infinity,
                        child: Stack(
                          children: [
                            Positioned(
                              // rectangle26YZP (208:547)
                              left: 0*fem,
                              top: 1*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 44*fem,
                                  height: 17*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      color: Color(0xffbd0505),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // deletefP7 (208:548)
                              left: 8*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 29*fem,
                                  height: 20*fem,
                                  child: Text(
                                    'DELETE',
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 8*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 2.5*ffem/fem,
                                      letterSpacing: 0.08*fem,
                                      color: Color(0xffd9d9d9),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                // firstnameAKs (208:550)
                left: 183*fem,
                top: 192*fem,
                child: Align(
                  child: SizedBox(
                    width: 71*fem,
                    height: 24*fem,
                    child: Text(
                      'First Name',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.7142857143*ffem/fem,
                        letterSpacing: 0.150000006*fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // lastnameryP (208:551)
                left: 183*fem,
                top: 256*fem,
                child: Align(
                  child: SizedBox(
                    width: 70*fem,
                    height: 24*fem,
                    child: Text(
                      'Last Name',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.7142857143*ffem/fem,
                        letterSpacing: 0.150000006*fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // emailaddressNRw (208:552)
                left: 171*fem,
                top: 320*fem,
                child: Align(
                  child: SizedBox(
                    width: 93*fem,
                    height: 24*fem,
                    child: Text(
                      'Email Address',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.7142857143*ffem/fem,
                        letterSpacing: 0.150000006*fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // password4Jm (208:553)
                left: 180*fem,
                top: 384*fem,
                child: Align(
                  child: SizedBox(
                    width: 64*fem,
                    height: 24*fem,
                    child: Text(
                      'Password',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.7142857143*ffem/fem,
                        letterSpacing: 0.150000006*fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // comfirmpassword9LD (208:554)
                left: 154*fem,
                top: 448*fem,
                child: Align(
                  child: SizedBox(
                    width: 123*fem,
                    height: 24*fem,
                    child: Text(
                      'Comfirm Password',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.7142857143*ffem/fem,
                        letterSpacing: 0.150000006*fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
          );
  }
}