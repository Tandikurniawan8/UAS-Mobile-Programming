import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone14promax1aCH (20:148)
        padding: EdgeInsets.fromLTRB(9*fem, 20*fem, 9*fem, 20*fem),
        width: double.infinity,
        height: 932*fem,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Container(
          // devicedeviceframeJ8H (20:149)
          width: double.infinity,
          height: double.infinity,
          decoration: BoxDecoration (
            border: Border.all(color: Color(0x7f8e918f)),
            color: Color(0xff1d1b20),
            borderRadius: BorderRadius.circular(18*fem),
          ),
          child: Stack(
            children: [
              Positioned(
                // statusbarcem (I20:149;50785:11431)
                left: 24*fem,
                top: 18*fem,
                child: Container(
                  width: 364*fem,
                  height: 24*fem,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Container(
                        // timeiho (I20:149;50785:11431;50758:11370)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 141*fem, 0*fem),
                        child: Text(
                          '9:30',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.4285714286*ffem/fem,
                            letterSpacing: 0.14*fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                      Container(
                        // cameracutoutQU9 (I20:149;50785:11431;50758:11371)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 124*fem, 0*fem),
                        width: 24*fem,
                        height: 24*fem,
                        child: Image.asset(
                          'assets/form-pendaftaran/images/camera-cutout.png',
                          width: 24*fem,
                          height: 24*fem,
                        ),
                      ),
                      Container(
                        // righticonsvhP (I20:149;50785:11431;50758:11372)
                        width: 46*fem,
                        height: 17*fem,
                        child: Image.asset(
                          'assets/form-pendaftaran/images/right-icons.png',
                          width: 46*fem,
                          height: 17*fem,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                // home4Ho (I20:149;50792:11371;50783:11414)
                left: 170*fem,
                top: 882*fem,
                child: Align(
                  child: SizedBox(
                    width: 72*fem,
                    height: 2*fem,
                    child: Container(
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(8*fem),
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // davatars13Yim (20:2641)
                left: 137*fem,
                top: 65*fem,
                child: Container(
                  width: 138*fem,
                  height: 135*fem,
                  child: Center(
                    // avatars3davatar134SD (20:2642)
                    child: SizedBox(
                      width: 138*fem,
                      height: 135*fem,
                      child: Image.asset(
                        'assets/form-pendaftaran/images/avatars-3davatar13.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // loginB13 (22:333)
                left: 186*fem,
                top: 213*fem,
                child: Align(
                  child: SizedBox(
                    width: 41*fem,
                    height: 20*fem,
                    child: Text(
                      'LOGIN',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.4285714286*ffem/fem,
                        letterSpacing: 0.14*fem,
                        color: Color(0xffd9d9d9),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // rectangle26e9X (20:2643)
                left: 116*fem,
                top: 323*fem,
                child: Align(
                  child: SizedBox(
                    width: 180*fem,
                    height: 18*fem,
                    child: Container(
                      decoration: BoxDecoration (
                        color: Color(0xffd9d9d9),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // rectangle3MZj (20:2644)
                left: 116*fem,
                top: 388*fem,
                child: Align(
                  child: SizedBox(
                    width: 180*fem,
                    height: 18*fem,
                    child: Container(
                      decoration: BoxDecoration (
                        color: Color(0xffd9d9d9),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // password5kd (22:336)
                left: 175*fem,
                top: 354*fem,
                child: Align(
                  child: SizedBox(
                    width: 67*fem,
                    height: 20*fem,
                    child: Text(
                      'Password:',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.4285714286*ffem/fem,
                        letterSpacing: 0.14*fem,
                        color: Color(0xffd9d9d9),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // usernameZvh (22:335)
                left: 174*fem,
                top: 283*fem,
                child: Align(
                  child: SizedBox(
                    width: 69*fem,
                    height: 20*fem,
                    child: Text(
                      'Username:',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.4285714286*ffem/fem,
                        letterSpacing: 0.14*fem,
                        color: Color(0xffd9d9d9),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // keyboarddark3ay (20:2405)
                left: 0*fem,
                top: 540*fem,
                child: Container(
                  padding: EdgeInsets.fromLTRB(7*fem, 9*fem, 7*fem, 8*fem),
                  width: 410*fem,
                  height: 338*fem,
                  decoration: BoxDecoration (
                    color: Color(0xff141218),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        // navbarwgM (I20:2405;52559:24795)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 17*fem),
                        width: double.infinity,
                        height: 26*fem,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // iconleft4ky (I20:2405;52559:24796)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 24*fem, 0*fem),
                              width: 26*fem,
                              height: 26*fem,
                              child: Image.asset(
                                'assets/form-pendaftaran/images/icon-left.png',
                                width: 26*fem,
                                height: 26*fem,
                              ),
                            ),
                            Container(
                              // iconrowaUR (I20:2405;52559:24798)
                              margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 1*fem),
                              height: double.infinity,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // iconscentreJvD (I20:2405;52559:24799)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 26*fem, 0*fem),
                                    padding: EdgeInsets.fromLTRB(0*fem, 2*fem, 2.75*fem, 2*fem),
                                    height: double.infinity,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // iconsgif24pxD1b (I20:2405;52559:24800)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0.29*fem, 42.27*fem, 0*fem),
                                          width: 24*fem,
                                          height: 10.29*fem,
                                          child: Image.asset(
                                            'assets/form-pendaftaran/images/icons-gif24px.png',
                                            width: 24*fem,
                                            height: 10.29*fem,
                                          ),
                                        ),
                                        Container(
                                          // iconssettingsfilled24pxiU9 (I20:2405;52559:24801)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 44.78*fem, 0*fem),
                                          width: 19.45*fem,
                                          height: 20*fem,
                                          child: Image.asset(
                                            'assets/form-pendaftaran/images/icons-settingsfilled24px.png',
                                            width: 19.45*fem,
                                            height: 20*fem,
                                          ),
                                        ),
                                        Container(
                                          // iconstranslate24pxq2y (I20:2405;52559:24802)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 45.25*fem, 0*fem),
                                          width: 19*fem,
                                          height: 19*fem,
                                          child: Image.asset(
                                            'assets/form-pendaftaran/images/icons-translate24px.png',
                                            width: 19*fem,
                                            height: 19*fem,
                                          ),
                                        ),
                                        Container(
                                          // iconssticker24pxYxy (I20:2405;52559:24803)
                                          width: 18.5*fem,
                                          height: 18.5*fem,
                                          child: Image.asset(
                                            'assets/form-pendaftaran/images/icons-sticker24px.png',
                                            width: 18.5*fem,
                                            height: 18.5*fem,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // dividerlineHQm (I20:2405;52559:24807)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 29*fem, 0*fem),
                                    width: 1*fem,
                                    height: 24*fem,
                                    decoration: BoxDecoration (
                                      color: Color(0xff49454f),
                                    ),
                                  ),
                                  Container(
                                    // iconsrightR1B (I20:2405;52559:24804)
                                    margin: EdgeInsets.fromLTRB(0*fem, 2.5*fem, 0*fem, 2.5*fem),
                                    height: double.infinity,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // iconsmore24pxLdw (I20:2405;52559:24805)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 39*fem, 0*fem),
                                          width: 16*fem,
                                          height: 4*fem,
                                          child: Image.asset(
                                            'assets/form-pendaftaran/images/icons-more24px.png',
                                            width: 16*fem,
                                            height: 4*fem,
                                          ),
                                        ),
                                        Container(
                                          // iconsmic24pxSBB (I20:2405;52559:24806)
                                          width: 14*fem,
                                          height: 19*fem,
                                          child: Image.asset(
                                            'assets/form-pendaftaran/images/icons-mic24px.png',
                                            width: 14*fem,
                                            height: 19*fem,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        // keyboardkhf (I20:2405;52559:24686)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 35*fem),
                        width: double.infinity,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // firstrowgrD (I20:2405;52559:24687)
                              width: double.infinity,
                              height: 46*fem,
                              decoration: BoxDecoration (
                                borderRadius: BorderRadius.circular(6*fem),
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // qQGR (I20:2405;52559:24688)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6.03*fem, 0*fem),
                                    width: 34.17*fem,
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0xff1d1b20),
                                      borderRadius: BorderRadius.circular(6*fem),
                                    ),
                                    child: Center(
                                      child: Center(
                                        child: Text(
                                          'q',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 21*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.1428571429*ffem/fem,
                                            color: Color(0xffe6e0e9),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // w4rm (I20:2405;52559:24691)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6.03*fem, 0*fem),
                                    width: 34.17*fem,
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0xff1d1b20),
                                      borderRadius: BorderRadius.circular(6*fem),
                                    ),
                                    child: Center(
                                      child: Center(
                                        child: Text(
                                          'w',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 21*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.1428571429*ffem/fem,
                                            color: Color(0xffe6e0e9),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // eLpH (I20:2405;52559:24694)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6.03*fem, 0*fem),
                                    width: 34.17*fem,
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0xff1d1b20),
                                      borderRadius: BorderRadius.circular(6*fem),
                                    ),
                                    child: Center(
                                      child: Center(
                                        child: Text(
                                          'e',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 21*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.1428571429*ffem/fem,
                                            color: Color(0xffe6e0e9),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // rEem (I20:2405;52559:24697)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6.03*fem, 0*fem),
                                    width: 34.17*fem,
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0xff1d1b20),
                                      borderRadius: BorderRadius.circular(6*fem),
                                    ),
                                    child: Center(
                                      child: Center(
                                        child: Text(
                                          'r',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 21*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.1428571429*ffem/fem,
                                            color: Color(0xffe6e0e9),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // tWcH (I20:2405;52559:24700)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6.03*fem, 0*fem),
                                    width: 34.17*fem,
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0xff1d1b20),
                                      borderRadius: BorderRadius.circular(6*fem),
                                    ),
                                    child: Center(
                                      child: Center(
                                        child: Text(
                                          't',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 21*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.1428571429*ffem/fem,
                                            color: Color(0xffe6e0e9),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // y1J9 (I20:2405;52559:24703)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6.03*fem, 0*fem),
                                    width: 34.17*fem,
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0xff1d1b20),
                                      borderRadius: BorderRadius.circular(6*fem),
                                    ),
                                    child: Center(
                                      child: Center(
                                        child: Text(
                                          'y',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 21*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.1428571429*ffem/fem,
                                            color: Color(0xffe6e0e9),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // uJY9 (I20:2405;52559:24706)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6.03*fem, 0*fem),
                                    width: 34.17*fem,
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0xff1d1b20),
                                      borderRadius: BorderRadius.circular(6*fem),
                                    ),
                                    child: Center(
                                      child: Center(
                                        child: Text(
                                          'u',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 21*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.1428571429*ffem/fem,
                                            color: Color(0xffe6e0e9),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // iAqF (I20:2405;52559:24709)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6.03*fem, 0*fem),
                                    width: 34.17*fem,
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0xff1d1b20),
                                      borderRadius: BorderRadius.circular(6*fem),
                                    ),
                                    child: Center(
                                      child: Center(
                                        child: Text(
                                          'i',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 21*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.1428571429*ffem/fem,
                                            color: Color(0xffe6e0e9),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // oFLu (I20:2405;52559:24712)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6.03*fem, 0*fem),
                                    width: 34.17*fem,
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0xff1d1b20),
                                      borderRadius: BorderRadius.circular(6*fem),
                                    ),
                                    child: Center(
                                      child: Center(
                                        child: Text(
                                          'o',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 21*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.1428571429*ffem/fem,
                                            color: Color(0xffe6e0e9),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // pL7T (I20:2405;52559:24715)
                                    width: 34.17*fem,
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0xff1d1b20),
                                      borderRadius: BorderRadius.circular(6*fem),
                                    ),
                                    child: Center(
                                      child: Center(
                                        child: Text(
                                          'p',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 21*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.1428571429*ffem/fem,
                                            color: Color(0xffe6e0e9),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              // autogroup6evmECq (JbNf56kUi5MoZyAkA36EvM)
                              padding: EdgeInsets.fromLTRB(0*fem, 12*fem, 0*fem, 0*fem),
                              width: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // secondrowZW1 (I20:2405;52559:24718)
                                    margin: EdgeInsets.fromLTRB(21*fem, 0*fem, 21*fem, 0*fem),
                                    width: double.infinity,
                                    height: 46*fem,
                                    decoration: BoxDecoration (
                                      borderRadius: BorderRadius.circular(6*fem),
                                    ),
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // ark1 (I20:2405;52559:24719)
                                          width: 34*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0xff1d1b20),
                                            borderRadius: BorderRadius.circular(6*fem),
                                          ),
                                          child: Center(
                                            child: Center(
                                              child: Text(
                                                'a',
                                                textAlign: TextAlign.center,
                                                style: SafeGoogleFont (
                                                  'Roboto',
                                                  fontSize: 21*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.1428571429*ffem/fem,
                                                  color: Color(0xffe6e0e9),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        SizedBox(
                                          width: 6*fem,
                                        ),
                                        Container(
                                          // sjYu (I20:2405;52559:24722)
                                          width: 34*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0xff1d1b20),
                                            borderRadius: BorderRadius.circular(6*fem),
                                          ),
                                          child: Center(
                                            child: Center(
                                              child: Text(
                                                's',
                                                textAlign: TextAlign.center,
                                                style: SafeGoogleFont (
                                                  'Roboto',
                                                  fontSize: 21*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.1428571429*ffem/fem,
                                                  color: Color(0xffe6e0e9),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        SizedBox(
                                          width: 6*fem,
                                        ),
                                        Container(
                                          // ddeH (I20:2405;52559:24725)
                                          width: 34*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0xff1d1b20),
                                            borderRadius: BorderRadius.circular(6*fem),
                                          ),
                                          child: Center(
                                            child: Center(
                                              child: Text(
                                                'd',
                                                textAlign: TextAlign.center,
                                                style: SafeGoogleFont (
                                                  'Roboto',
                                                  fontSize: 21*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.1428571429*ffem/fem,
                                                  color: Color(0xffe6e0e9),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        SizedBox(
                                          width: 6*fem,
                                        ),
                                        Container(
                                          // ftq7 (I20:2405;52559:24728)
                                          width: 34*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0xff1d1b20),
                                            borderRadius: BorderRadius.circular(6*fem),
                                          ),
                                          child: Center(
                                            child: Center(
                                              child: Text(
                                                'f',
                                                textAlign: TextAlign.center,
                                                style: SafeGoogleFont (
                                                  'Roboto',
                                                  fontSize: 21*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.1428571429*ffem/fem,
                                                  color: Color(0xffe6e0e9),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        SizedBox(
                                          width: 6*fem,
                                        ),
                                        Container(
                                          // gAnd (I20:2405;52559:24731)
                                          width: 34*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0xff1d1b20),
                                            borderRadius: BorderRadius.circular(6*fem),
                                          ),
                                          child: Center(
                                            child: Center(
                                              child: Text(
                                                'g',
                                                textAlign: TextAlign.center,
                                                style: SafeGoogleFont (
                                                  'Roboto',
                                                  fontSize: 21*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.1428571429*ffem/fem,
                                                  color: Color(0xffe6e0e9),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        SizedBox(
                                          width: 6*fem,
                                        ),
                                        Container(
                                          // hrQZ (I20:2405;52559:24734)
                                          width: 34*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0xff1d1b20),
                                            borderRadius: BorderRadius.circular(6*fem),
                                          ),
                                          child: Center(
                                            child: Center(
                                              child: Text(
                                                'h',
                                                textAlign: TextAlign.center,
                                                style: SafeGoogleFont (
                                                  'Roboto',
                                                  fontSize: 21*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.1428571429*ffem/fem,
                                                  color: Color(0xffe6e0e9),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        SizedBox(
                                          width: 6*fem,
                                        ),
                                        Container(
                                          // jvfK (I20:2405;52559:24737)
                                          width: 34*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0xff1d1b20),
                                            borderRadius: BorderRadius.circular(6*fem),
                                          ),
                                          child: Center(
                                            child: Center(
                                              child: Text(
                                                'j',
                                                textAlign: TextAlign.center,
                                                style: SafeGoogleFont (
                                                  'Roboto',
                                                  fontSize: 21*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.1428571429*ffem/fem,
                                                  color: Color(0xffe6e0e9),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        SizedBox(
                                          width: 6*fem,
                                        ),
                                        Container(
                                          // kQqP (I20:2405;52559:24740)
                                          width: 34*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0xff1d1b20),
                                            borderRadius: BorderRadius.circular(6*fem),
                                          ),
                                          child: Center(
                                            child: Center(
                                              child: Text(
                                                'k',
                                                textAlign: TextAlign.center,
                                                style: SafeGoogleFont (
                                                  'Roboto',
                                                  fontSize: 21*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.1428571429*ffem/fem,
                                                  color: Color(0xffe6e0e9),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        SizedBox(
                                          width: 6*fem,
                                        ),
                                        Container(
                                          // l6y7 (I20:2405;52559:24743)
                                          width: 34*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0xff1d1b20),
                                            borderRadius: BorderRadius.circular(6*fem),
                                          ),
                                          child: Center(
                                            child: Center(
                                              child: Text(
                                                'l',
                                                textAlign: TextAlign.center,
                                                style: SafeGoogleFont (
                                                  'Roboto',
                                                  fontSize: 21*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.1428571429*ffem/fem,
                                                  color: Color(0xffe6e0e9),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  SizedBox(
                                    height: 12*fem,
                                  ),
                                  Container(
                                    // thirdrown5F (I20:2405;52559:24746)
                                    width: double.infinity,
                                    height: 46*fem,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // leftshiftL6m (I20:2405;52559:24747)
                                          width: 55*fem,
                                          height: 46*fem,
                                          child: Image.asset(
                                            'assets/form-pendaftaran/images/left-shift.png',
                                            width: 55*fem,
                                            height: 46*fem,
                                          ),
                                        ),
                                        SizedBox(
                                          width: 6*fem,
                                        ),
                                        Container(
                                          // thirdrowp1w (I20:2405;52559:24750)
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(6*fem),
                                          ),
                                          child: Row(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // zJSu (I20:2405;52559:24751)
                                                width: 34*fem,
                                                height: double.infinity,
                                                decoration: BoxDecoration (
                                                  color: Color(0xff1d1b20),
                                                  borderRadius: BorderRadius.circular(6*fem),
                                                ),
                                                child: Center(
                                                  child: Center(
                                                    child: Text(
                                                      'z',
                                                      textAlign: TextAlign.center,
                                                      style: SafeGoogleFont (
                                                        'Roboto',
                                                        fontSize: 21*ffem,
                                                        fontWeight: FontWeight.w400,
                                                        height: 1.1428571429*ffem/fem,
                                                        color: Color(0xffe6e0e9),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              SizedBox(
                                                width: 6*fem,
                                              ),
                                              Container(
                                                // xkph (I20:2405;52559:24754)
                                                width: 34*fem,
                                                height: double.infinity,
                                                decoration: BoxDecoration (
                                                  color: Color(0xff1d1b20),
                                                  borderRadius: BorderRadius.circular(6*fem),
                                                ),
                                                child: Center(
                                                  child: Center(
                                                    child: Text(
                                                      'x',
                                                      textAlign: TextAlign.center,
                                                      style: SafeGoogleFont (
                                                        'Roboto',
                                                        fontSize: 21*ffem,
                                                        fontWeight: FontWeight.w400,
                                                        height: 1.1428571429*ffem/fem,
                                                        color: Color(0xffe6e0e9),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              SizedBox(
                                                width: 6*fem,
                                              ),
                                              Container(
                                                // cDyB (I20:2405;52559:24757)
                                                width: 34*fem,
                                                height: double.infinity,
                                                decoration: BoxDecoration (
                                                  color: Color(0xff1d1b20),
                                                  borderRadius: BorderRadius.circular(6*fem),
                                                ),
                                                child: Center(
                                                  child: Center(
                                                    child: Text(
                                                      'c',
                                                      textAlign: TextAlign.center,
                                                      style: SafeGoogleFont (
                                                        'Roboto',
                                                        fontSize: 21*ffem,
                                                        fontWeight: FontWeight.w400,
                                                        height: 1.1428571429*ffem/fem,
                                                        color: Color(0xffe6e0e9),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              SizedBox(
                                                width: 6*fem,
                                              ),
                                              Container(
                                                // vJzd (I20:2405;52559:24760)
                                                width: 34*fem,
                                                height: double.infinity,
                                                decoration: BoxDecoration (
                                                  color: Color(0xff1d1b20),
                                                  borderRadius: BorderRadius.circular(6*fem),
                                                ),
                                                child: Center(
                                                  child: Center(
                                                    child: Text(
                                                      'v',
                                                      textAlign: TextAlign.center,
                                                      style: SafeGoogleFont (
                                                        'Roboto',
                                                        fontSize: 21*ffem,
                                                        fontWeight: FontWeight.w400,
                                                        height: 1.1428571429*ffem/fem,
                                                        color: Color(0xffe6e0e9),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              SizedBox(
                                                width: 6*fem,
                                              ),
                                              Container(
                                                // bCaD (I20:2405;52559:24763)
                                                width: 34*fem,
                                                height: double.infinity,
                                                decoration: BoxDecoration (
                                                  color: Color(0xff1d1b20),
                                                  borderRadius: BorderRadius.circular(6*fem),
                                                ),
                                                child: Center(
                                                  child: Center(
                                                    child: Text(
                                                      'b',
                                                      textAlign: TextAlign.center,
                                                      style: SafeGoogleFont (
                                                        'Roboto',
                                                        fontSize: 21*ffem,
                                                        fontWeight: FontWeight.w400,
                                                        height: 1.1428571429*ffem/fem,
                                                        color: Color(0xffe6e0e9),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              SizedBox(
                                                width: 6*fem,
                                              ),
                                              Container(
                                                // nHLm (I20:2405;52559:24766)
                                                width: 34*fem,
                                                height: double.infinity,
                                                decoration: BoxDecoration (
                                                  color: Color(0xff1d1b20),
                                                  borderRadius: BorderRadius.circular(6*fem),
                                                ),
                                                child: Center(
                                                  child: Center(
                                                    child: Text(
                                                      'n',
                                                      textAlign: TextAlign.center,
                                                      style: SafeGoogleFont (
                                                        'Roboto',
                                                        fontSize: 21*ffem,
                                                        fontWeight: FontWeight.w400,
                                                        height: 1.1428571429*ffem/fem,
                                                        color: Color(0xffe6e0e9),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              SizedBox(
                                                width: 6*fem,
                                              ),
                                              Container(
                                                // myUV (I20:2405;52559:24769)
                                                width: 34*fem,
                                                height: double.infinity,
                                                decoration: BoxDecoration (
                                                  color: Color(0xff1d1b20),
                                                  borderRadius: BorderRadius.circular(6*fem),
                                                ),
                                                child: Center(
                                                  child: Center(
                                                    child: Text(
                                                      'm',
                                                      textAlign: TextAlign.center,
                                                      style: SafeGoogleFont (
                                                        'Roboto',
                                                        fontSize: 21*ffem,
                                                        fontWeight: FontWeight.w400,
                                                        height: 1.1428571429*ffem/fem,
                                                        color: Color(0xffe6e0e9),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          width: 6*fem,
                                        ),
                                        Container(
                                          // backspaceUAM (I20:2405;52559:24772)
                                          width: 55*fem,
                                          height: 46*fem,
                                          child: Image.asset(
                                            'assets/form-pendaftaran/images/backspace.png',
                                            width: 55*fem,
                                            height: 46*fem,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  SizedBox(
                                    height: 12*fem,
                                  ),
                                  Container(
                                    // bottomrowaUH (I20:2405;52559:24775)
                                    width: double.infinity,
                                    height: 46*fem,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // Wcq (I20:2405;52559:24776)
                                          width: 55*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0xff4a4458),
                                            borderRadius: BorderRadius.circular(100*fem),
                                          ),
                                          child: Center(
                                            child: Text(
                                              '?123',
                                              style: SafeGoogleFont (
                                                'Roboto',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w500,
                                                height: 1.4285714286*ffem/fem,
                                                color: Color(0xffe8def8),
                                              ),
                                            ),
                                          ),
                                        ),
                                        SizedBox(
                                          width: 6*fem,
                                        ),
                                        Container(
                                          // emojiQiD (I20:2405;52559:24778)
                                          width: 34*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0xff36343b),
                                            borderRadius: BorderRadius.circular(6*fem),
                                          ),
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                // 9Qu (I20:2405;52559:24779)
                                                left: 14.5*fem,
                                                top: 14*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 25*fem,
                                                    child: Text(
                                                      ',',
                                                      textAlign: TextAlign.center,
                                                      style: SafeGoogleFont (
                                                        'Roboto',
                                                        fontSize: 21*ffem,
                                                        fontWeight: FontWeight.w400,
                                                        height: 1.1725*ffem/fem,
                                                        color: Color(0xffcac4d0),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // emojiFTw (I20:2405;52559:24780)
                                                left: 11*fem,
                                                top: 10*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 12*fem,
                                                    height: 12*fem,
                                                    child: Image.asset(
                                                      'assets/form-pendaftaran/images/emoji.png',
                                                      width: 12*fem,
                                                      height: 12*fem,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          width: 6*fem,
                                        ),
                                        Container(
                                          // qwbf (I20:2405;52559:24788)
                                          width: 34*fem,
                                          height: 46*fem,
                                          child: Image.asset(
                                            'assets/form-pendaftaran/images/q.png',
                                            width: 34*fem,
                                            height: 46*fem,
                                          ),
                                        ),
                                        SizedBox(
                                          width: 6*fem,
                                        ),
                                        Container(
                                          // lightcolorkeyborder03Gdw (I20:2405;52559:24790)
                                          width: 154*fem,
                                          height: 46*fem,
                                          child: Image.asset(
                                            'assets/form-pendaftaran/images/light-color-key-border03.png',
                                            width: 154*fem,
                                            height: 46*fem,
                                          ),
                                        ),
                                        SizedBox(
                                          width: 6*fem,
                                        ),
                                        Container(
                                          // periodPyT (I20:2405;52559:24791)
                                          width: 34*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0xff36343b),
                                            borderRadius: BorderRadius.circular(6*fem),
                                          ),
                                          child: Center(
                                            child: Text(
                                              '.',
                                              textAlign: TextAlign.center,
                                              style: SafeGoogleFont (
                                                'Roboto',
                                                fontSize: 21*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.1725*ffem/fem,
                                                color: Color(0xffcac4d0),
                                              ),
                                            ),
                                          ),
                                        ),
                                        SizedBox(
                                          width: 6*fem,
                                        ),
                                        Container(
                                          // enterkeyGnM (I20:2405;52559:24793)
                                          width: 55*fem,
                                          height: 46*fem,
                                          child: Image.asset(
                                            'assets/form-pendaftaran/images/enter-key.png',
                                            width: 55*fem,
                                            height: 46*fem,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        // bottomnav1E9 (I20:2405;52559:24680)
                        margin: EdgeInsets.fromLTRB(17.41*fem, 0*fem, 15*fem, 0*fem),
                        width: double.infinity,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              // collapse8Jm (I20:2405;52559:24684)
                              margin: EdgeInsets.fromLTRB(0*fem, 1.91*fem, 133.41*fem, 0*fem),
                              width: 11.18*fem,
                              height: 6.77*fem,
                              child: Image.asset(
                                'assets/form-pendaftaran/images/collapse.png',
                                width: 11.18*fem,
                                height: 6.77*fem,
                              ),
                            ),
                            Container(
                              // devicedeviceframecomponentsnav (I20:2405;52559:24681)
                              margin: EdgeInsets.fromLTRB(0*fem, 21*fem, 131*fem, 0*fem),
                              width: 72*fem,
                              height: 2*fem,
                              child: Image.asset(
                                'assets/form-pendaftaran/images/device-device-frame-components-navigation.png',
                                width: 72*fem,
                                height: 2*fem,
                              ),
                            ),
                            Container(
                              // keyboard20pxjpM (I20:2405;52559:24682)
                              width: 16*fem,
                              height: 10*fem,
                              child: Image.asset(
                                'assets/form-pendaftaran/images/keyboard20px.png',
                                width: 16*fem,
                                height: 10*fem,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                // signins9s (208:539)
                left: 177*fem,
                top: 499*fem,
                child: Align(
                  child: SizedBox(
                    width: 51*fem,
                    height: 20*fem,
                    child: Text(
                      'SIGN IN',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.4285714286*ffem/fem,
                        letterSpacing: 0.14*fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                // autogroupstcmA8y (JbNePhiTV2Muvh3vVfsTcm)
                left: 146*fem,
                top: 436*fem,
                child: Container(
                  width: 120*fem,
                  height: 20*fem,
                  child: Stack(
                    children: [
                      Positioned(
                        // rectangle26sp5 (208:544)
                        left: 0*fem,
                        top: 2*fem,
                        child: Align(
                          child: SizedBox(
                            width: 120*fem,
                            height: 17*fem,
                            child: Container(
                              decoration: BoxDecoration (
                                color: Color(0xff0e5faa),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // submitzth (208:545)
                        left: 34*fem,
                        top: 0*fem,
                        child: Align(
                          child: SizedBox(
                            width: 52*fem,
                            height: 20*fem,
                            child: Text(
                              'SUBMIT',
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.4285714286*ffem/fem,
                                letterSpacing: 0.14*fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
          );
  }
}